########################################
# Introducion: vectores e bucles en R #
########################################

# O tipo de dato mais basico en R e un vector.
# Creanse coa funcion c()
a <- c(1, 0, 1, 5, 3)
b <- c(2, 0, 1, -1, -2)
a
b

# O comando ':' permite construir vectores de
# numeros enteiros moi facilmente.
x <- 1:10
x
x <- 3:12
x
x <- 6:2
x

### Operacions cun vector: ###
# Todas as operacions basicas fanse elemento a elemento
a + 1
a - 2
a * 3
a^2

# Ademais, todas as funcions matematicas basicas estan en R.
# Igual que as operacions, funcionan elemento a elemento
#   - As funcions trigonometricas
sin(a)  # Seno
cos(a)  # Coseno
tan(a)  # Tanxente
#   - A exponencial (e^x)
exp(a)
#   - A raiz cadrada
sqrt(a)

# Se tedes dubidas como funciona unha funcion de R, sempre
# podedes consultar a sua axuda
?sin

### Funcions especiais para un vector ###
# As mais basicas son
#   - O minimo
min(a)
#   - O maximo
max(a)
#   - A lonxitude do vector
length(a)
#   - A suma dos seus elementos
sum(a)
#   - O produto dos seus elementos
prod(a)


### Operacions con dous vectores ###
# Se temos dous vectores de igual lonxitude podemos
# facer as operacions basicas con eles
length(a)
length(b)

# A operacions funcionan elemento a elemento
a + b
a - b
a * b
b ^ a

# COIDADO! O vectores tenhen que ter a mesma lonxitude.
# Se non, R fai cousas raras
b <- 1:3
a + b       # Aqui so suma a 'a' o primeiro elemnto de 'b'
a <- 1:6
a + b       # Aqui suma a 'a' o vector c(1,2,3,1,2,3)

### Subvectores en R ###
# Para escoller un elemento dun vector, indicamos la posicion
# do elemento que queremos entre corchetes (EMPEZANDO EN 1!)
a <- c(1, 0, 5, 3, 2)
#   - O primeiro elemento
a[1]
#   - O cuarto
a[4]
#   - O ultimo
a[length(a)]

# Se quero coller varios elementos tenho que pasar un vector
# coas posicions que quero
a[c(2, 4, 1)]
# Para isto e moi util o comando ':'
#   - Os tres primeiros elementos
a[1:3]
#   - Os tres ultimos (COIDADO COS PARENTESES!)
a[(length(a)-2):length(a)]

# Tamen se poden crear subvectores empregando operadores loxicos
#   - Os elementos de a maiores que 2
a[a>2]
#   - Os elementos de a menores ou iguales que 3
a[a<=3]
#   - Os elementos de a distintos de 0
a[a!=0]

### Bucles en R ###
# Hai varias formas de facer bucles en R
# A mais basica e un bucle for
for (i in 1:5){
    print(i)
}

# Vexamos como sumar todos os elementos dun vector co bucle for
a <- c(0, -1, 3, 2, 8, -4)
suma <- 0
for (i in 1:length(a)){
    suma <- suma + a[i]
}
# O resultado e
suma
# Se o fixemos ben, ten que coincidir coa funcion sum
sum(a)


####################################################
# Exercicio 1. Operacions con vectores e matrices #
####################################################

###################
### Apartado a) ###
###################
# Cargamos o vector t e pasamolo por pantalla
t <- c(0, 0.25, 0.5, 0.75)
t
# Esta e a maneira basica de crealo. Hai varias mais:
#   - Con seq():
seq(0, 0.75, by = 0.25)         # Indicando a distancia entre dous valores
seq(0, 0.75, length.out = 4)    # Indicando a lonxitude final do vector
#   - Con dous puntos:
(0:3)/4

# Ordenamolo de forma decrecente coa funcion sort
sort(t, decreasing=TRUE)

# Calculamos a suma dos elementos de t ao cadrado
sum(t^2)
# E o seno do vector t elemento a elemento
sin(2*pi*t)
# Hai erros de redondeo. Se queremos facer unha aproximacion,
# podemos facela coa funcion round(). Neste caso aproximamos
# ao terceiro decimal.
round(sin(2*pi*t), 3)

###################
### Apartado b) ###
###################

# Creamos o vector coa esperanza de vida de cada pais
esp.vida <- c(83.2, 82.5, 83.0, 83.4, 82.4, 81.4, 81.4, 81.8, 81.6)
# e damoslle nome a cada observacion
names(esp.vida) <- c("Espanha", "Francia", "Italia", "Suiza", "Luxemburgo",
                     "Belgica", "Reino Unido", "Irlanda", "Portugal")
esp.vida

# Calculamos a esperanza de vida media con mean()
media <- mean(esp.vida)
media
# Tamen podramos facer un sum() e dividir pola lonxitude do vector
sum(esp.vida)/length(esp.vida)

# Valores por debaixo da media
esp.vida[esp.vida < media]
# Valores por enriba da media
esp.vida[esp.vida > media]

###################
### Apartado c) ###
###################

# Cargamos a matriz A. Recordade que por defecto R introduce
# os datos POR COLUMNA. Para facelo por fila, tenho que especificalo
# con byrow = TRUE
A <- matrix(1:16, nrow = 4, ncol = 4, byrow = TRUE)
A

# A matriz B
B <- matrix(1:16, nrow = 4, ncol = 4)
B
# Tambien podia construila con la funcion t(),
# que devolve la trasposta duna matriz
t(A)

# O produto matricial
C <- A%*%B
C

# A inversa calculase con solve()
solve(C)
# Neste caso non nos devolve nada porque a matriz non e invertible.
# Calculamos o determinante con det()
det(C)
# e vemos que se anula (toma un valor moi baixo).

# Con eigen() calculamos os autovalores e os autovetores da matriz
eigen(C)
# So nos interesan os autovectores
autoval <- eigen(C)$values
autoval

# Comprobamos se o produto dos autovalores coincide co determinante
prod(eigen(C)$values)
det(C)
# Non coinciden por erros de redondeo en R. En realidade ambos son cero.

# Comprobamos que a suma dos autovalores coincide coa traza
sum(autoval)
sum(diag(C))
# Vemos que si coinciden

#######################################
### Exercicio 2: creacion de listas ###
#######################################

# A listas son parecidas aos vectores. A maior diferencia e
# que nos permiten almacenar xuntos datos de distinto tipo:
# vectores numericos, de caracteres, loxicos, matrices...
enquisa <- list(padres=c("Juan","Josefina"),nhijos=3,edadhijos=c(16,11,4),
                notas=matrix(c(8,3,7,5,5,10,4,7,4,7),nrow=2,ncol=5))
enquisa

# Podo acceder a cada elemento da lista con $
enquisa$nhijos
enquisa$notas

# Tamen puedo modificalos como queira. Vou a cambiar os
# nomes das filas e das columnas da matriz notas.
colnames(enquisa$notas) <- c('Padre', 'Madre', 'Hijo1', 'Hijo2', 'Hijo3')
rownames(enquisa$notas) <- c('Enclave', 'Hotel')
enquisa

###########################################
### Exercicio 3: diagrama de dispersion ###
###########################################

# Gardamos as variables hectareas e ocupacion
hectareas <- c(0.8, 1.1, 0.6, 3.2, 1.4, 2.1, 1.5, 0.2, 1.0, 6.1)
ocupacion <- c(1200, 650, 1060, 235, 1300, 300, 750, 150, 440, 500)
# Vemos que tenhen a mesma lonxitude
length(hectareas)
length(ocupacion)

# Debuxamos o diagrama de dispersion
plot(hectareas, ocupacion)
# Podemos engadir rectas ao debuxo con abline()
# Engadimos a media de hectareas cunha recta vertical
abline(v = mean(hectareas))
# Engadimos a media de ocupacion cunha recta horizontal
abline(h = mean(ocupacion))

# Podemos cambiar as cores co parametro col
abline(h = mean(ocupacion), col = 'red')
abline(v = mean(hectareas), col = 'blue')

# Tamen podemos cambiar as cores dos puntos no plot orixinal
# Creamos a variable zona
zona <- c(1, 1, 1, 2, 3, 2, 3, 3, 3, 2)
# E la pasamola como parametro de cores a plot
plot(hectareas, ocupacion, col=zona)

######################################
### Exercicio 4: crear unha funcion ###
######################################

# Imos crear unha funcion que nos devolva unha
# palabra formada por 5 letras escollidas ao azar

# Declaramos a funcion
ejer4 <- function(){
    # Cargamos as letras do alfabeto espanhol
    letras <- c(letters[1:14], "nh", letters[15:length(letters)])
    # Escollemos 5 letras ao azar con reemplazamento
    sorteo <- sample(letras,5,replace=T)
    # Pegamolas coa funcion paste()
    palabra <- paste(sorteo, collapse='')
    # Indicamos que a funcion devolva a palabra que acabamos de crear
    return(palabra)
}

# Executamos a funcion
ejer4()
# Cada vez que a executamos deberiamos ter unha palabra distinta (mais ou menos)


# Imos modificar a funcion para que nos permita engadir un parametro
# de entrada. Imos construir unha funcion que escolla aleatoriamente
# n letras e que as pegue para formar unha palabra

# O parametro de entrada vai entre parenteses
ejer4n <- function(n){
    
    letras <- c(letters[1:14], "nh", letters[15:length(letters)])
    # O unico cambio esta no sample. En vez de escoller 5 letras
    # imos escoller n letras
    sorteo <- sample(letras,n,replace=T)
    palabra <- paste(sorteo, collapse='')
    return(palabra)
}

# Executamos a funcion indicando o valor de n
ejer4n(5) # Cinco letras (como antes)
ejer4n(7) # Sete letras
ejer4n(10)# Dez letras

####################################################
### Exercicio 5: como instalar e cargar paquetes ###
####################################################

# Para instalar novos paquetes en R emplease a funcion
# install.packages(), indicando o nome do paquete entre comillas
install.packages('ggplot2')

# Se quero instalar varios a vez, podo facelo pasandolle
# un vector cos nombres
install.packages(c('usmap', 'maps'))

# Para poder usar un paquete tenemos que cargalo coa funcion library()

# Cargamos os paquetes que acabamos de instalar:
library(ggplot2)
library(usmap)
library(maps)

# ATA AQUI O IMPORTANTE DESTE EXERCICIO
# O seguinte codigo o que fai e debuxar dos mapas de EEUU
# empregando os paquetes que acabamos de instalar e cargar


# O primeiro mapa. So aparecen todos os estados (menos Alaska e Hawaii)
# pintados de cores distintas
states <- map_data("state")
ggplot(data = states) +
    geom_polygon(aes(x=long,y=lat,fill=region,group=group),color="white") +
    coord_fixed(1.3) +
    xlab("Lonxitude") +
    ylab("Latitude") +
    ggtitle("Estados Unidos") +
    guides(fill="none")


# O segundo mapa. E similar ao anterior, pero agora a cor de cada
# estado indica a porcentaxe de poboacion que esta debaixo 
# do umbral da pobreza. Cuanto mais rosa sexa, maior poboacion
# pobre tera (en porcentaxe)
povper <- statepov$pct_pov_2014[match(states$region, tolower(statepov$full))]
ggplot(data = states) +
    geom_polygon(aes(x=long,y=lat, fill=povper, group=group), color="white") +
    coord_fixed(1.3) + 
    scale_fill_continuous(low = "green", high = "magenta",
                          name = "% de poboacion\npobre",
                          labels = seq(10, 20, length.out = 5),
                          breaks = seq(10, 20, length.out = 5)) + 
    scale_y_continuous(breaks = NULL, name = NULL) +
    scale_x_continuous(breaks = NULL, name = NULL) +
    ggtitle('Porcentaxe de poboacion por debaixo\ndo umbral da pobreza') +
    theme(legend.position = "right",
                  plot.title = element_text(face = 'bold', size = rel(1.5),
                                            hjust = 0.5))

# REPITO: NON E NECESARIO SABER QUE FAI EXACTAMENTE O CODIGO DE ARRIBA
# O importante deste exercicio e saber como cargar e instalar paquetes


######################################
### Exercicio 6: cargar datos en R ###
######################################

# Descarga o arquivo de datos seguindo a ruta indicada no exercicio.

# Antes de cargalo, temos que cambiar o directorio de traballo de R.
# Isto podese facer na lapela files como vimos en clase.
# ('pestanha' en galego dise 'lapela')
# Tamen se pode facer coa funcion setwd, seguida da ruta
# do directorio.
# No meu ordenador persona seria
setwd("D:/Users/diego.bolon/Escritorio/ClasesETSE/Practica 1 - Intro R")
# Reparade en que a ruta vai con '/' e non con '\'

# Se queredes saber cal e o directorio de traballo actual,
# sempre podes utilizar a funcion getwd()
getwd()

# Cargamos os datos coa funcion read.csv
datos <- read.csv("DatosIGE.csv")
# Por defecto, o read.csv entende que
#   - A primeira fila do arquivo e un encabezado
#   - Cada elemento esta separado por unha coma
#   - As cifras decimais se separan cun punto
# Se consultades a axuda, veredes como podedes cargar isto
?read.csv

# Vexamos se cargamos ben os datos
# Co comando fix() abrimos unha nova ventana onde podremos consultalos
fix(datos)
# Isto pode dar problemas nalguns ordenadores.
# En tal caso, sempre poderemos usar head() para mostrar as seis primeiras
# filas da tabla
head(datos)


############################################
### PRACTICA 3: ANALISIS DE DATOS REALES ###
############################################

###################
### EJERCICIO 1 ###
###################

# Cargamos los datos y vemos que todo va bien
pokemon <- read.csv('pokemon.csv')
head(pokemon)

### Apartado a)
# El summary() ya nos da seis
summary(pokemon$ATK)

### Apartado b)
# Histograma
hist(pokemon$ATK, main = 'Histograma ATK', xlab = 'Ataque', ylab = 'Frecuencia')
# Boxplot
boxplot(pokemon$ATK, main = 'Boxplot ATK', ylab = 'Ataque')

### Apartado c)
# Cuales son los atipicos?
atip <- (pokemon$ATK  > quantile(pokemon$ATK, 0.75) + 1.5*IQR(pokemon$ATK))
atip
pokemon[atip,]


### Apartado d)
# Repetimos todo para DEF
summary(pokemon$DEF)
hist(pokemon$DEF, main = 'Histograma DEF', xlab = 'Defensa', ylab = 'Frecuencia')
boxplot(pokemon$DEF, main = 'Boxplot DEF', ylab = 'Defensa')

# Asimetria???
library(moments)
skewness(pokemon$DEF)


# Cuales son los atipicos?
atip.def <- (pokemon$DEF  > quantile(pokemon$DEF, 0.75) + 1.5*IQR(pokemon$DEF))
atip.def
pokemon[atip.def,]

### Apartados e) y f)
# Ataque y defensa de un pokemon estan relacionados?
x <- pokemon$ATK
y <- pokemon$DEF
plot(x, y, pch = 20)

# Covarianza
covar <- sum((x-mean(x))*(y-mean(y))) / nrow(pokemon)
covar
# La funcion cov
cov(x, y)
# Devuelve la covarianza corregida
# Puedo corregirla yo a mano
covar2 <- cov(x, y) * (nrow(pokemon) - 1) / nrow(pokemon)
covar2
# El coeficiente de correlacion
var.ATK <- sum((x-mean(x))^2) / nrow(pokemon)
var.DEF <- sum((y-mean(y))^2) / nrow(pokemon)
coef.cor <- covar / sqrt(var.ATK * var.DEF)
coef.cor
# La funcion cor
cor(x, y)
# NO HAY QUE CORREGIRLA!!!
# Hay correlacion positiva entre las variables:
# cuanto mas ataque tenga un pokemon, mas defensa tiene.

### Apartado g)
# La recta de regresion???
# Podria calcular los coeficientes a mano.
#   - La pendiente
b <- covar / var.ATK
b
#   - El intercepto
a <- mean(y) - b * mean(x)
a

# Voy a anhadir la recta al grafico de dispersion
plot(x, y, xlab = 'Ataque', ylab = 'Defensa', main = 'Recta de regresion',
     pch = 20)
abline(a = a, b = b, col = 'red', lwd = 2)

### Apartado h)
# Cuanto se equivoca la recta de regresion? Esto se mide con los residuos
residuos <- y - (a + b*x)
# Representamos los residuos
plot(x, residuos, xlab = 'Ataque', ylab = 'Residuos', 
     main = 'Residuos de la recta de regresion', pch = 20)
abline(h = 0, col = 'red', lwd = 2)

# Hay claramente un punto que es atipico dentro de la regresion:
# su residuo es muy grande
# Veamos cual es:
pokemon[residuos == max(residuos), ]
# O tambien:
pokemon[which.max(residuos),]

# Tambien hay un atipico por el otro lado
pokemon[residuos == min(residuos), ]
# O tambien
pokemon[which.min(residuos), ]

# Todo esto que hicimos a mano, se puede hacer con la funcion lm()
reg <- lm(y~x)
reg
# Hacer un summary() del modelo de regresion es muy interesante
summary(reg)
# El objeto que devuelve lm() tiene un monton de informacion
names(reg)
reg$coefficients
reg$residuals
reg$fitted.values

# Puedo hasta dibujarla automaticamente
plot(x, y, xlab = 'Ataque', ylab = 'Defensa', main = 'Recta de regresion', pch = 20)
abline(reg, col = 'red', lwd = 2)

###################
### EJERCICIO 2 ###
###################


### Apartado a)
# El summary() ya da seis
summary(pokemon$SP_ATK)

### Apartado b)
# Histograma
hist(pokemon$SP_ATK, main = 'Histograma SP_ATK', xlab = 'Ataque especial', ylab = 'Frecuencia')
# Boxplot
boxplot(pokemon$SP_ATK, main = 'Boxplot SP_ATK', ylab = 'Ataque especial')

### Apartado c)
# Cueles son los atipicos?
atip <- (pokemon$SP_ATK  > quantile(pokemon$SP_ATK, 0.75) + 1.5*IQR(pokemon$SP_ATK))
atip
pokemon[atip,]


### Apartado d)
# Repetimos todo para SP_DEF
summary(pokemon$SP_DEF)
hist(pokemon$SP_DEF, main = 'Histograma SP_DEF', xlab = 'Defensa especial', ylab = 'Frecuencia')
boxplot(pokemon$SP_DEF, main = 'Boxplot SP_DEF', ylab = 'Defensa especial')


# Cuales son los atipicos?
atip.def <- (pokemon$SP_DEF  > quantile(pokemon$SP_DEF, 0.75) + 1.5*IQR(pokemon$SP_DEF))
atip.def
pokemon[atip.def,]

### Apartados e) y f)
# Ataque y defensa especial de un pokemon estan relacionados?
x <- pokemon$SP_ATK
y <- pokemon$SP_DEF
plot(x, y, pch = 20)

# Covarianza
covar <- sum((x-mean(x))*(y-mean(y))) / nrow(pokemon)
covar
# La funcion cov
cov(x, y)
# Devuelve la covarianza corregida
# Podo des-corregirla yo a mano
covar2 <- cov(x, y) * (nrow(pokemon) - 1) / nrow(pokemon)
covar2
# El coeficiente de correlacion
var.SP_ATK <- sum((x-mean(x))^2) / nrow(pokemon)
var.SP_DEF <- sum((y-mean(y))^2) / nrow(pokemon)
coef.cor <- covar / sqrt(var.SP_ATK * var.SP_DEF)
coef.cor
# La funcion cor
cor(x, y)
# NO HAY QUE CORREGIRLA!!!
# Hay correlacion positiva entre las variables:
# cuanto mas ataque tenga un pokemon, mas defensa tiene.

### Apartado g)
# La recta de regresion???
# Podria calcular los coeficientes a mano.
#   - La pendente
b <- covar / var.SP_ATK
b
#   - El intercepto
a <- mean(y) - b * mean(x)
a

# Voy a anhadir la recta al grafico de dispersion
plot(x, y, xlab = 'Ataque especial', ylab = 'Defensa especial', main = 'Recta de regresion',
     pch = 20)
abline(a = a, b = b, col = 'red', lwd = 2)

### Apartado h)
# Cuanto se equivoca la recta de regresion? Esto se mide con los residuos
residuos <- y - (a + b*x)
# Representamos los residuos
plot(x, residuos, xlab = 'Ataque especial', ylab = 'Residuos', 
     main = 'Residuos de la recta de regresion', pch = 20)
abline(h = 0, col = 'red', lwd = 2)

# Hay claramente un punto que es atipico dentro de la regresion:
# su residuo es muy grande
# Veamos cual es:
pokemon[residuos == max(residuos), ]
# O tambien:
pokemon[which.max(residuos),]

# Por el otro lado:
pokemon[residuos == max(residuos), ]
# O tambien:
pokemon[which.min(residuos), ]


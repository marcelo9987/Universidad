###################
### Exercicio 1 ###
###################

### Apartado a) ###

# O soporte
x <- 1:6
# A masa de probabilidade
px <- (13-2*x)/36 #seq(11, 1, by = -2) / 36
sum(px)
# A funcion de distribucion
Fx <- cumsum(px)

# Representamos a masa de probabilidade (type="h" indica debuxar liñas verticais)
plot(x, px, type = 'h', xlim = c(0.5, 6.5), ylim = c(0, 0.35),
     main = 'Masa de probablidade', xlab = 'x', ylab = 'P(X=x)')
# Barplot
barplot(px, names = x, xlab = 'x', ylab = 'P(X=x)',
        main = 'Masa de probabilidade', ylim = c(0, 0.35))
# A moda da distribucion e x = 1

# A funcion de distribucion (type="s" indica que queremos representar función a saltos)
plot(x, Fx, type = 's', main = 'Funcion de distribucion',
     xlab = 'x', ylab = 'F(x)', xlim = c(0.5, 6.5), ylim = c(-0.1, 1.1))
# Por defecto so debuxa de x=1 a x=6.
# Alargamola un pouco para que quede mellor:
segments(0.5,0,1,0)   # Segmento dende (0.5,0) a (1, 0)
segments(1,0,1,Fx[1]) # Segmento dende (1,0) a (1, F(1))
segments(6,1,6.5,1)   # Segmento dende (6,1) a (6.5, 1)

### Apartado b) ###

# A esperanza da variable aleatoria
Ex <- sum(x*px)
Ex
# Con weighted.mean
weighted.mean(x, px)

# A varianza
Vx <- sum((x-Ex)^2*px)
Vx
# Ou pola outra formula
sum(x^2*px) - Ex^2

###################
### Exercicio 2 ###
###################

### Apartado a) ###

# A funcion de densidade
fdens <- function(x){
  return(0.75*(1 - x^2))
}
# Aproximamos a integral
integrate(fdens, -1, 1)

# A funcion de distribucion
Fdist <- function(x){
  -x^3/4+3/4*x+1/2
}

### Apartado b) ###

# Representamos a funcion de densidade
x <- seq(-1, 1, by = 0.01)
plot(x, fdens(x), type = 'l', xlim = c(-1.5, 1.5), ylim = c(-0.05, 0.8),
     main = 'Funcion de densidade', xlab = 'x', ylab = 'f(x)')
segments(-1.5, 0, -1, 0)
segments(1,0, 1.5, 0)

# A moda e x = 0

# Representamos a funcion de distribucion
plot(x, Fdist(x), type = 'l', xlim = c(-1.5, 1.5), ylim = c(-0.05, 1.05),
     main = 'Funcion de distribucion', xlab = 'x', ylab = 'F(x)')
segments(-1.5, 0, -1, 0)
segments(1,1, 1.5, 1)

### Apartado c) ###

# A probabilidade de que -0.5 < X < 1:
integrate(fdens, -0.5, 1)
Fdist(1) - Fdist(-0.5)

# Calculamos a media con integrate
f_med <- function(x){
  return(x*fdens(x))
}
Ex <- integrate(f_med, -1, 1)
Ex

# Ex e unha lista con moitas cousas dentro
names(Ex)
# Nos so nos interesa o valor da integral
Ex <- Ex$value
Ex

# Calculamos a varianza
f_var <- function(x){
  return((x - Ex)^2*fdens(x))
}
integrate(f_var, -1, 1)

###################
### Exercicio 3 ###
###################

### Apartado a) ###

# Xeramos aleatoriamente 5 valores con rbinom
# Neste caso
#   - size = 6
#   - prob = 0.3
rbinom(5, 6, 0.3)

### Apartado b) ###

# Calculamos a probabilidade de que X <= 4
# Igual que antes
#   - size = 6
#   - prob = 0.3
pbinom(4, 6, 0.3)

# Tamen o podiamos facer sumando todas as
# probabilidades desde 0 ata 4
sum(dbinom(0:4, 6, 0.3))

### Apartado c) ###

# A probabilidade de que 3 <= X <= 5
sum(dbinom(3:5, 6, 0.3))

# Tamen o podo facer con pbinom:
pbinom(5, 6, 0.3) - pbinom(2, 6, 0.3)

### Apartado d) ###

# Xeramos catro valores dunha binomial negativa
# Neste caso:
#   - size = 8
#   - prob = 0.4
rnbinom(4, 8, 0.4)

### Apartado e) ###

# Xeramos catro valores dunha binomial negativa
# Neste caso:
#   - size = 8
#   - prob = 0.6
rnbinom(4, 8, 0.6)

### Apartado f) ###

# X = numero de erros antes do primeiro acerto

# Neste caso, X sigue unha distribucion xeometrica
# que coincide cunha binomial negativa con parametros
#   - size = 1
#   - prob = 0.65

# Calculamos a probabilidade de que X = 3
dnbinom(3, 1, 0.65)

# Pidesenos a probabilidade de X <= 3
pnbinom(3, 1, 0.65)
# Tamen o podo facer sumando todas
sum(dnbinom(0:3, 1, 0.65))

### Apartado g) ###

# Neste caso X e unha Poisson con lambda = 2

# A probabilidade de que X >= 4
1 - ppois(3, 2)

# Non o podo facer sumando a probabilidade de todos
# os puntos porque o soporte da Poisson e infinito!!!

# O que si que podo facer e calcular a probabilidade
# de todos os menores que catro e restarlla a 1
1 - sum(dpois(0:3, 2))

####################
### Exercicio 4) ###
####################

### Apartado a) ###

# X = numero de erros no xogo A
# Y = numero de erros no xogo B

# Tanto X coma Y siguen unha distribucion binomial
# X = Bi(3, 0.5)
# Y = Bi(6, 0.5)

# A probabilidade de ganhar o xogo A e a probabilidade
# de ter cero erros: P(X = 0)
winA <- dbinom(0, 3, 0.5)
winA

# A probabilidade de ganhar o xogo B e a probabilidade
# de ter 2 ou menos erros: P(Y <= 2)
winB <- pbinom(2, 6, 0.5)
winB

### Apartado b) ###

# Ponderamos a probabilidade de ganhar cada xogo
# pola probabilidade de que nos toque
0.4 * winA + 0.6 * winB

###################
### Exercicio 5 ###
###################

### Apartado a) ###

# X = numero de treboles nas ''cartas por salir''

# X sigue unha distribucion hiperxeometrica. Os parametros en R
#   - m: o numero de treboles que quedan na baralla. 
#        m = 13 - 4 = 9
#   - n: o resto de cartas que quedan na barralla.
#        n = 52 - 5 - 9 = 38
#   - k: as cartas que quedan.
#        k = 2

# Daquela a probabilidade de completar ''color'' e
# a probablididade que polo menos saia un trebol.
# P(X >= 1)
pcolor <- 1 - dhyper(0, 9, 38, 2)
pcolor

# Tamen o podo facer sumando todas as probabilidades
# individuais
sum(dhyper(1:2, 9, 38, 2))

### Apartado b) ###

# Planteamos unha nova variable

# Y = numero de treboles nas 5 cartas da mesa

# e unha hiperxeometrica. Neste caso, os parametros son
#   - m = 13 - 2 = 11
#   - n = 52 - 2 - 11 = 39
#   - k = 5

# A probabilidade de color agora e P(Y >= 3).
1 - phyper(2, 11, 39, 5)

# Tamen o podo facer sumando todas as
# probabilidade individuais
sum(dhyper(3:5, 11, 39, 5))

###################
### Exercicio 6 ###
###################

### Apartado a) ###

# Xeramos 10 valores dunha uniforme con runif
# Os parametros son
#   - min = 0
#   - max = 1
runif(10, 0, 1)

# Como son os valores por defecto
# podo non indicalos
runif(10)

# Cambiamos a uniforme. Agora:
#   - min = 3
#   - max = 4
runif(15, 3, 4)


### Apartado b) ###

# X = N(160, 100)
# En R, os parametros son
#   - mean = 160
#   - sd = sqrt(100) = 10

# A funcion de distribucion e pnorm. Enton:
#   - P(X <= 150)
pnorm(150, 160, 100)
#   - P(X <= 160)
pnorm(160, 160, 100)
# Como a normal e simetrica, a probabilidade
# anterior e 0.5 (media e mediana coinciden)

### Apartado c) ###

# Xeramos 100 valores da normal N(1, 4)
datos <- rnorm(100, 1, 2)

# Imos facer un histograma con eles:
hist(datos, freq = F, main = '100 observacions dunha N(1, 4)',
     xlab = 'x', ylab = 'Densidade')

# Imos debuxar enriba a densidade da variable
x <- seq(min(datos), max(datos), by = 0.01)
fx <- dnorm(x, 1, 2)
lines(x, fx, col = 'red')


### Apartado d) ###

# Debuxamolas todas xuntas:
x <- seq(-4, 4, by = 0.01)
plot(x, dnorm(x), type = 'l',
     main = 'Distribucions normais',
     ylab = 'Densidade',
     ylim = c(0, 1))
lines(x, dnorm(x, 0, 2), col = 2)
lines(x, dnorm(x, 0, 0.5), col = 3)
legend('topright', legend = c('N(0,1)', 'N(0,4)', 'N(0,0.25)'),
       col = 1:3, lwd = 1)

### Apartado e) ###

# Debuxamolas todas xuntas:
x <- seq(-3, 4, by = 0.01)
plot(x, dnorm(x), type = 'l',
     main = 'Distribucions normais',
     ylab = 'Densidade',
     ylim = c(0, 1))
lines(x, dnorm(x, 2, 1), col = 2)
lines(x, dnorm(x, -1, 0.5), col = 3)
legend('topright', legend = c('N(0,1)', 'N(2,1)', 'N(-1,0.25)'),
       col = 1:3, lwd = 1)


### Apartado f) ###

# A mediana dunha normal N(0,1)
qnorm(0.5)
# Coincide coa media!!!

# O cuantil 0.05 da normal N(0,1)
qnorm(0.05)

# O cuantil 0.8 da normal N(160, 64)
qnorm(0.8, 160, 8)


### Apartado g) ###

# A masa de probabilidade dunha Bi(40, 0.25)
plot(0:40, dbinom(0:40, 40, 0.25), type = 'h',
     main = 'Aproximacion normal dunha binomial',
     xlab = 'x',
     ylab = 'y')

# A densidade da normal por enriba
mu <- 40 * 0.25
sigma2 <- 40 * 0.25 * (1 - 0.25)
x <- seq(0, 40, by = 0.1)
lines(x, dnorm(x, mu, sqrt(sigma2)), col = 2)
legend('topright', legend = c('Bi(40, 0.25)', 'N(10, 7.5)'),
       col = 1:2, lwd = 1)

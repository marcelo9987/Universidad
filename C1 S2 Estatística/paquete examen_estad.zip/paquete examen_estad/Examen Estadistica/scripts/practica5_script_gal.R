###################################################################
#### PRACTICA 7: ESTIMACION PUNTUAL E INTERVALOS DE CONFIANZA  ####
###################################################################


#########################################
### Exercicio 1: Poblacions normais ###
#########################################

# Cargamos os datos
datos<-read.csv(file="datos_practica5.csv")
head(datos)


### Apartado a: Media con varianza conhecida

# A desviacion estandar e
sigma <- sqrt(2)

# Imoslle ponher un nome a mostra para que
# sexa mais comodo
x1 <- datos$x1

# O tamanho da mostra
n <- length(x1)
n
# A media da mostra
media <- mean(x1)
media

# A desviacion estandar do estimador
des_est <- sigma/sqrt(n)
des_est

# Intervalo de confianza ao 90%
nivel <- 0.9
alfa <- 1-nivel
# Calculamos o cuantil
z <- qnorm(1-alfa/2,mean=0,sd=1)

# Os extremos
inf <- media-z*des_est
sup <- media+z*des_est
intervalo <- c(inf, sup)
intervalo

# Coa funcion Mean.CI faise directamente
# Primeiro temos que cargar o paquete
library(LearningStats)
Mean.CI(x1, sigma=sigma, conf.level=nivel)



### Apartado b: Media con varianza desconhecida

# Ponhemoslle un nome facil aos datos
x2 <- datos$x2

# O tamanho da mostra (e o mesmo que antes)
n <- length(x2)
n
# A media da mostra
media <- mean(x2)
media
# A cuasidesviacion estandar
cde <- sd(x2)
des_est <- cde/sqrt(n)
des_est

# Intervalo de confianza ao 95%
nivel <- 0.95
alfa <- 1-nivel

# Calculamos o cuantil superio
t <- qt(1 - alfa/2, df = n - 1)
inf <- media-t*des_est
sup <- media+t*des_est
intervalo <- c(inf, sup)
intervalo

# Coa funcion Mean.CI do paquete LearningStats
Mean.CI(x2, conf.level=nivel)

### Apartado c: Varianza con media desconhecida

x3 <- datos$x3
# O tamanho da mostra
n <- length(x3)
# A cuasivarianza
cvar <- var(x3)
cvar  

# Intervalo de confianza para a varianza ao nivel de 97%

nivel <- 0.97
alfa <- 1-nivel
# Os dous cuantis
chi1 <- qchisq(alfa/2, df = n-1)
chi2 <- qchisq(1 - alfa/2, df = n-1)
inf <- (n-1)*cvar/chi2
sup <- (n-1)*cvar/chi1
intervalo_var=c(inf, sup)
intervalo_var

# Intervalo de confianza para a desviacion estandar
intervalo_de <- sqrt(intervalo_var)
intervalo_de

# Coa funcion variance.CI do paquete LearningStats
variance.CI(x3,conf.level=nivel)


###############################
### Exercicio 2: Proporcion ###
###############################

# O numero de probas
n <- 200
# O numero de probas defectuosas
defectuosas <- 9
# Estimamos a proporcion
pgorro <- defectuosas/n
pgorro

# Calculamos a desviacion estandar da estimacion
des_est <- sqrt(pgorro*(1-pgorro)/n)
des_est
# Intervalo de confianza para a proporcion ao nivel do 99%
nivel <- 0.99
alfa <- 1-nivel
z <- qnorm(1-alfa/2)
inf <- pgorro-z*des_est
sup <- pgorro+z*des_est
intervalo=c(inf, sup)
intervalo

# Coa funcion proportion.CI do paquete LearningStats
proportion.CI(x=defectuosas,n=n,conf.level=nivel)


#########################################
# PRACTICA 6: Distribucions na mostraxe #
#########################################

###################
### EXERCICIO 1 ###
###################
# A media dunha normal:

# O tamanho das mostrsas
n <-100
# O numero de mostras
rep <- 500
# A media
mu <- 160
# A desviacion estandar
sigma <- 8

# Facemos todo nun bucle for:
est <- 1:rep
for (i in 1:rep){
    # Xeramos a i-esima mostra
    x <- rnorm(n, mu, sigma)
    # Calculamos o estatistico
    est[i] <- sqrt(n)*(mean(x) - mu)/sigma
}

# Vexamos se est segue a distribucion que ten que ter
hist(est, freq = F, ylim=c(0,0.45))
# Parece unha campana de Gauss
# Debuxamos a campana por riba do histograma
x <- seq(min(est), max(est), by = 0.01)
lines(x, dnorm(x), col = 'red')


###################
### EXERCICIO 2 ###
###################
# A varianza dunha normal


# O numero de mostras
rep <- 500
# Os tamanhos das mostras
ns <- c(5, 10, 20, 50)
# A media
mu <- 3
# A desviacion tipica
sigma <- 0.5

# Debuxamos os catro histogramas dentro dun bucle
# Partimos a pantalla grafica
par(mfrow = c(2,2))
for(n in ns){
    # Para cada tamanho, xeramos 500 mostras
    est <- 1:rep
    for(i in 1:rep){
        # Xeramos a mostra
        x <- rnorm(n, mu, sigma)
        # Calculamos o  estatistico
        est[i] <- (n-1)*var(x)/sigma^2
    }
    # Para cada tamanho, debuxamos os valores
    # do estatistico nun histograma
    hist(est, freq = F, main = paste0('n = ', n))
    # Debuxamos a chi cadrado por riba
    x <- seq(min(est), max(est), length.out = 201)
    lines(x, dchisq(x, n-1), col = 'red')
}


###################
### EXERCICIO 3 ###
###################
# T de Student a partir dunha normal e unha chi
# cadrado

# Os tamanhos das mostras
ns <-c(50, 100, 1000, 5000)

# Creamos un bucle para xerar as mostras
# de cada tamanho
par(mfrow = c(2,2))
for(n in ns){
    
    # Xeramos a normal estandar
    norm <- rnorm(n)
    # Xeramos a chi cadrado
    chi <- rchisq(n, 5)
    
    # A mostra T de student e
    t <- norm/sqrt(chi/5)
    
    # Representamola
    hist(t, freq = F, main = paste0('n = ', n), ylim=c(0,0.4))
    # Xunto coa sua densidade
    x <- seq(min(t), max(t), length.out = 201)
    lines(x, dt(x, 5), col = 'red')
}

###################
### EXERCICIO 4 ###
###################
# A media dunha normal con varianza desconhecida

# O numero das mostras
rep <- 500
# Os tamanhos das mostras
ns <- c(10, 20, 100, 500)
# A media
mu <- 5
# A desviacion tipica
sigma <- sqrt(1)

# Creamos un bucle recorrendo os tamanhos
par(mfrow=c(2,2))
for (n in ns){
    # Vector onde imos gardar o estatistico
    est <- 1:rep
    # Para cada tamanho xeramos rep = 500 mostras
    for (i in 1:rep){
        # Xeramos a mostra normal
        x <- rnorm(n, mu, sigma)
        # O estatistico
        est[i] <- sqrt(n)*(mean(x) - mu)/sd(x)
    }
    # O histograma do estatistico
    hist(est, freq = F,
         main = paste0('n = ', n),
         ylab = 'Densidade',
         ylim = c(0,0.4))
    # Comparamolo coa T correspondente
    x <- seq(min(est), max(est), length.out = 201)
    lines(x, dt(x, n-1), col = 'red')
}






















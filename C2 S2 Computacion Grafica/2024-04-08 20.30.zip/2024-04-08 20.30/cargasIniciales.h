#pragma once

#include "comun.h"
#include "sistemaSolar.h"


/**
* @brief Inicializa la configuraci�n del sistema solar
*/
void inicializaConfiguracionSistema();

/**
* @brief Inicializa la configuraci�n de la c�mara
* @param[in] cuerpoCeleste Cuerpo celeste a inicializar
*/
void inicializaPosicionCuerpoCeleste(CuerpoCeleste* cuerpoCeleste);


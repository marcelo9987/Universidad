package Estructura;

import java.util.*;

/**
 * Tipo de Estructura.
 */
public class Base extends Estructura {

    /**
     * Default constructor
     */
    public Base() {
    }

    /**
     * 
     */
    public void crearUnidad() {
        // TODO implement here
    }

}
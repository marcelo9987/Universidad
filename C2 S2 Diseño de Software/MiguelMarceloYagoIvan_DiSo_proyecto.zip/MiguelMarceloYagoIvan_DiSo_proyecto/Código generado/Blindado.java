package Estructura;

import java.util.*;

/**
 * Añade al dron el equipamiento necesario para aumentar su resistencia a un ataque.
 */
public class Blindado extends Equipador {

    /**
     * Default constructor
     */
    public Blindado() {
    }

    /**
     * 
     */
    public void resistencia;

}
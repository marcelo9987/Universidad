package Estructura;

import java.util.*;

/**
 * Cada una de las partes que componen al tablero y en las que puede haber Unidades o una Estructura, así como recursos.
 */
public class Celda extends Observable {

    /**
     * Default constructor
     */
    public Celda() {
    }

    /**
     * 
     */
    private Integer coordX;

    /**
     * 
     */
    private Integer coordY;

    /**
     * 
     */
    private float recursos;

    /**
     * 
     */
    public void imprimir() {
        // TODO implement here
    }

    /**
     * 
     */
    public void esTransitable() {
        // TODO implement here
    }

    /**
     * 
     */
    public void repararEstructura() {
        // TODO implement here
    }

    /**
     * @param self
     */
    public void añadirUnidad(Unidad self) {
        // TODO implement here
    }

    /**
     * 
     */
    public void notificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtenerUnidad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void atacar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void recibirDaño() {
        // TODO implement here
    }

}
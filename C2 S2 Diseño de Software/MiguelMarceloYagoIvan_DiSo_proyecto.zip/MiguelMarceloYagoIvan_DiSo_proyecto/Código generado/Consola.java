package Estructura;

import java.util.*;

/**
 * Clase encargada de recibir las distintas operaciones y procesarlas para enviar la petición específica a la clase Fachada.
 */
public class Consola {

    /**
     * Default constructor
     */
    public Consola() {
    }

    /**
     * @param Comando
     */
    public void ejecutar(String Comando) {
        // TODO implement here
    }

}
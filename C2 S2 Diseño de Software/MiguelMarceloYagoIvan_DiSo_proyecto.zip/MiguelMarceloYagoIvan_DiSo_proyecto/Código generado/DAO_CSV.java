package Estructura;

import java.util.*;

/**
 * 
 */
public class DAO_CSV implements IDAO {

    /**
     * Default constructor
     */
    public DAO_CSV() {
    }

    /**
     * 
     */
    public void cargar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void volcar() {
        // TODO implement here
    }

    /**
     * 
     */
    private void leer() {
        // TODO implement here
    }

    /**
     * 
     */
    private void escribir() {
        // TODO implement here
    }

    /**
     * 
     */
    public void cargar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void volcar() {
        // TODO implement here
    }

}
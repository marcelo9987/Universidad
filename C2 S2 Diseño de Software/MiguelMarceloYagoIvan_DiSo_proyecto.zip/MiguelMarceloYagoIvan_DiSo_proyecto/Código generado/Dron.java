package Estructura;

import java.util.*;

/**
 * Tipo de Unidad.
 */
public abstract class Dron extends Unidad {

    /**
     * Default constructor
     */
    public Dron() {
    }

    /**
     * @param u
     */
    public void atacarUnidad(Unidad u) {
        // TODO implement here
    }

    /**
     * @param e
     */
    public void atacarEstructura(Estructura e) {
        // TODO implement here
    }

}
package Estructura;

import java.util.*;

/**
 * Versión básica del dron, sin nada equipado.
 */
public class DronLigero extends Dron {

    /**
     * Default constructor
     */
    public DronLigero() {
    }

}
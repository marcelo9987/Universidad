package Estructura;

import java.util.*;

/**
 * Es el "decorador" encargado de equipar al dron con el equipamiento pertinente.
 */
public class Equipador extends Dron {

    /**
     * Default constructor
     */
    public Equipador() {
    }

    /**
     * 
     */
    public void mover() {
        // TODO implement here
    }

    /**
     * 
     */
    public void atacar() {
        // TODO implement here
    }

}
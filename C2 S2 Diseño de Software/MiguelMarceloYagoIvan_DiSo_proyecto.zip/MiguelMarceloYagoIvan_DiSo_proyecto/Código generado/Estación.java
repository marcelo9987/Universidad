package Estructura;

import java.util.*;

/**
 * Tipo de Estructura.
 */
public class Estación extends Estructura {

    /**
     * Default constructor
     */
    public Estación() {
    }

    /**
     * 
     */
    public void crearUnidad() {
        // TODO implement here
    }

}
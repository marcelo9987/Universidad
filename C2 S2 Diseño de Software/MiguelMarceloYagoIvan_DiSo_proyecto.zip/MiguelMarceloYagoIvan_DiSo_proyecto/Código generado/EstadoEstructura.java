package Estructura;

import java.util.*;

/**
 * Diferentes estados en los que puede estar una estructura.
 */
public class EstadoEstructura {

    /**
     * Default constructor
     */
    public EstadoEstructura() {
    }

}
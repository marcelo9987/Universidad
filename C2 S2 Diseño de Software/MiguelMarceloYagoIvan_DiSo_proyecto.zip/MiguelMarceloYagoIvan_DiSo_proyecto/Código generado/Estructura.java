package Estructura;

import java.util.*;

/**
 * Clase abstracta de la que heredan las clases base, torre y estación, las diferentes estructuras que una potencia puede tener.
 */
public abstract class Estructura {

    /**
     * Default constructor
     */
    public Estructura() {
    }

    /**
     * 
     */
    private float salud;

    /**
     * @return
     */
    public abstract Unidad crearUnidad();

    /**
     * 
     */
    public void reparar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void regenerarSalud() {
        // TODO implement here
    }

    /**
     * @param daño
     */
    public void recibirDaño(void daño) {
        // TODO implement here
    }

    /**
     * 
     */
    public void establecerEstado() {
        // TODO implement here
    }

}
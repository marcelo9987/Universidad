package Estructura;

import java.util.*;

/**
 * Estado de la estructura en el que  ha sido dañada todavía y puede ser reparada.
 */
public class EstructuraDañada extends EstadoEstructura {

    /**
     * Default constructor
     */
    public EstructuraDañada() {
    }

}
package Estructura;

import java.util.*;

/**
 * Estado de la estructura en el que no ha sido dañada todavía y no puede ser reparada.
 */
public class EstructuraNueva extends EstadoEstructura {

    /**
     * Default constructor
     */
    public EstructuraNueva() {
    }

    /**
     * @param daño
     */
    public void recibirDaño(void daño) {
        // TODO implement here
    }

}
package Estructura;

import java.util.*;

/**
 * Clase que recibe las instrucciones introducidas de consola y ejecuta las operaciones
 * correspondientes, accediendo tanto a Potencia como a Tablero.
 */
public class Fachada {

    /**
     * Default constructor
     */
    public Fachada() {
    }

    /**
     * @param Nombre 
     * @param Potencia
     */
    public void crearJugador(String Nombre, Integer Potencia) {
        // TODO implement here
    }

    /**
     * @param tipoTablero
     */
    public void crearTablero(Integer tipoTablero) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Integer getNumPotencias() {
        // TODO implement here
        return null;
    }

    /**
     * @param potencia
     */
    public void registrarPotencias(Potencia potencia) {
        // TODO implement here
    }

    /**
     * 
     */
    public void representarTablero() {
        // TODO implement here
    }

    /**
     * 
     */
    public void pasarTurno() {
        // TODO implement here
    }

    /**
     * @param idEstructura 
     * @param coordY 
     * @param coordX
     */
    public void crearUnidad(Integer idEstructura, Integer coordY, Integer coordX) {
        // TODO implement here
    }

    /**
     * @param tipoEstructura 
     * @param coordX 
     * @param coordY
     */
    public void crearEstructura(String tipoEstructura, Integer coordX, Integer coordY) {
        // TODO implement here
    }

    /**
     * @param nombreUnidad 
     * @param dir
     */
    public void moverUnidad(void nombreUnidad, void dir) {
        // TODO implement here
    }

    /**
     * 
     */
    private void Fachada() {
        // TODO implement here
    }

    /**
     * 
     */
    public static void getInstance() {
        // TODO implement here
    }

    /**
     * @param nombreRobot 
     * @param coordX 
     * @param coordY 
     * @param tipoEstructura
     */
    public void construir(void nombreRobot, void coordX, void coordY, void tipoEstructura) {
        // TODO implement here
    }

    /**
     * @param coordX 
     * @param coordY
     */
    public void repararEstructura(void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * @param unidad
     */
    public void notificarPotenciasUnidadMovida(Unidad unidad) {
        // TODO implement here
    }

    /**
     * @param nombreRobot
     */
    public void transferirRecursosRobPotencia(String nombreRobot) {
        // TODO implement here
    }

    /**
     * @param potenciaPropone
     */
    public void aceptarAlianza(String potenciaPropone) {
        // TODO implement here
    }

    /**
     * @param nombre 
     * @return
     */
    public Potencia obtenerPotencia(String nombre) {
        // TODO implement here
        return null;
    }

    /**
     * @param potenciaPropone 
     * @param potenciaPropuesta
     */
    public void proponerAlianza(String potenciaPropone, String potenciaPropuesta) {
        // TODO implement here
    }

    /**
     * @param coordX 
     * @param coordY
     */
    public void desagruparUnidades(void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * @param potenciaActiva
     */
    public void eliminarPropuestaAlianza(String potenciaActiva) {
        // TODO implement here
    }

    /**
     * 
     */
    public void revocarAlianza() {
        // TODO implement here
    }

    /**
     * @param unidad 
     * @param coordX 
     * @param coordY 
     * @param potenciaAtacada
     */
    public void atacar(String unidad, void coordX, void coordY, String potenciaAtacada) {
        // TODO implement here
    }

}
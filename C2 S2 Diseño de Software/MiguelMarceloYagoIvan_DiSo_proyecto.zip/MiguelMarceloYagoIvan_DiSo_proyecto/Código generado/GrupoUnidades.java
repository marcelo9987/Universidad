package Estructura;

import java.util.*;

/**
 * 
 */
public class GrupoUnidades extends Unidad {

    /**
     * Default constructor
     */
    public GrupoUnidades() {
    }

    /**
     * 
     */
    public void anadir() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void desagrupar() {
        // TODO implement here
    }

}
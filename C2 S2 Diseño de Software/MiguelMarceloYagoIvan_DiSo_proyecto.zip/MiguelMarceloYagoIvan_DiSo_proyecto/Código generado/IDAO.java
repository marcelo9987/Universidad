package Estructura;

import java.util.*;

/**
 * 
 */
public interface IDAO {

    /**
     * 
     */
    public void cargar();

    /**
     * 
     */
    public void volcar();

}
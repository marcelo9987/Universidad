package Estructura;

import java.util.*;

/**
 * 
 */
public interface IObservador extends Torre {

    /**
     * 
     */
    public void Actualizar();

}
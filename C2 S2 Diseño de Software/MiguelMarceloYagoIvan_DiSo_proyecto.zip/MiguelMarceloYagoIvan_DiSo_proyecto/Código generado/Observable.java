package Estructura;

import java.util.*;

/**
 * 
 */
public class Observable {

    /**
     * Default constructor
     */
    public Observable() {
    }

    /**
     * @param observador
     */
    public void Adscribir(IObservador observador) {
        // TODO implement here
    }

    /**
     * @param observador
     */
    public void Quitar(IObservador observador) {
        // TODO implement here
    }

}
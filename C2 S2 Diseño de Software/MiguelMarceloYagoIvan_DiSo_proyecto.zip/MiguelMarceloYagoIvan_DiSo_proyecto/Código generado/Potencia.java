package Estructura;

import java.util.*;

/**
 * Clase que contiene los datos de la Potencia y accede a las Estructuras y Unidades de la misma.
 */
public class Potencia {

    /**
     * Default constructor
     */
    public Potencia() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private Integer codigo;

    /**
     * 
     */
    public List alianzasPropuestas;

    /**
     * 
     */
    private float recursos;

    /**
     * @param estructura
     */
    public void registrarEstructura(Estructura estructura) {
        // TODO implement here
    }

    /**
     * @param unidad
     */
    public void registrarUnidad(Unidad unidad) {
        // TODO implement here
    }

    /**
     * @param idEstructura 
     * @param coordY 
     * @param coordX
     */
    public void crearUnidad(Integer idEstructura, Integer coordY, Integer coordX) {
        // TODO implement here
    }

    /**
     * @param tipoEstructura 
     * @param coordX 
     * @param coordY
     */
    public void crearEstructura(String tipoEstructura, Integer coordX, Integer coordY) {
        // TODO implement here
    }

    /**
     * @param nombreUnidad 
     * @param coordX 
     * @param coordY
     */
    public void moverUnidad(void nombreUnidad, void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * 
     */
    public void cogerRecursos() {
        // TODO implement here
    }

    /**
     * @param tipoEstructura
     */
    public void consumirRecursos(void tipoEstructura) {
        // TODO implement here
    }

    /**
     * @param unidad
     */
    public void notificarTorresUnidadMovida(Unidad unidad) {
        // TODO implement here
    }

    /**
     * @param nombreRobot
     */
    public void reclamarRecursosRobot(String nombreRobot) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Boolean hayAlianzasActivas() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void revocarAlianzaActiva() {
        // TODO implement here
    }

    /**
     * @param aliado
     */
    public void registrarAliado(Potencia aliado) {
        // TODO implement here
    }

    /**
     * @param potenciaPropone
     */
    public void proponerAlianza(Potencia potenciaPropone) {
        // TODO implement here
    }

    /**
     * @param potenciaPropone
     */
    public void registrarPropuestaAlianza(Potencia potenciaPropone) {
        // TODO implement here
    }

    /**
     * @param potenciaPropone
     */
    public void aceptarAlianza(String potenciaPropone) {
        // TODO implement here
    }

    /**
     * @param potenciaPropone
     */
    public void hayProposicion(String potenciaPropone) {
        // TODO implement here
    }

    /**
     * @param coordX 
     * @param coordY
     */
    public void getUnidad(void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * @param e 
     * @param coordX 
     * @param coordY
     */
    public void atacarEstructura(Estructura e, void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * @param u
     */
    public void atacarUnidad(Unidad u) {
        // TODO implement here
    }

    /**
     * @param coordX 
     * @param coordY 
     * @return
     */
    public Estructura getEstructura(void coordX, void coordY) {
        // TODO implement here
        return null;
    }

}
package Estructura;

import java.util.*;

/**
 * 
 */
public class Recursos {

    /**
     * Default constructor
     */
    public Recursos() {
    }

    /**
     * 
     */
    private String Tipo;

    /**
     * 
     */
    private Integer Cantidad;

}
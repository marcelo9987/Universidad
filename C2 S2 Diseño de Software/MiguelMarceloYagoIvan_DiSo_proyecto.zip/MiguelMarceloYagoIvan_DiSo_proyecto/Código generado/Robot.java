package Estructura;

import java.util.*;

/**
 * Tipo de Unidad.
 */
public class Robot extends Unidad {

    /**
     * Default constructor
     */
    public Robot() {
    }

    /**
     * 
     */
    private Integer recursosMaximos;

    /**
     * 
     */
    public void getCoords() {
        // TODO implement here
    }

    /**
     * @param tipoEstructura
     */
    public void crearEstructura(void tipoEstructura) {
        // TODO implement here
    }

    /**
     * @param robot
     */
    public void reclamarRecursos(Robot robot) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Boolean puedoTransferir() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void extraer() {
        // TODO implement here
    }

}
package Estructura;

import java.util.*;

/**
 * Tipo de Unidad.
 */
public class Rover extends Unidad {

    /**
     * Default constructor
     */
    public Rover() {
    }

}
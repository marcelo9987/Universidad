package Estructura;

import java.util.*;

/**
 * Da contexto al juego, contiene las celdas.
 */
public class Tablero {

    /**
     * Default constructor
     */
    public Tablero() {
    }

    /**
     * 
     */
    public void asignarRecursos() {
        // TODO implement here
    }

    /**
     * @param c
     */
    public void addCeldas(List c) {
        // TODO implement here
    }

    /**
     * 
     */
    public void imprimir() {
        // TODO implement here
    }

    /**
     * @param unidad 
     * @param coordX 
     * @param coordY
     */
    public void moverUnidadA(void unidad, void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * @param coordX 
     * @param coordY
     */
    public void esTransitable(void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * @param coordX 
     * @param coordY
     */
    public void reparar(void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * 
     */
    public void hayRobotCerca() {
        // TODO implement here
    }

}
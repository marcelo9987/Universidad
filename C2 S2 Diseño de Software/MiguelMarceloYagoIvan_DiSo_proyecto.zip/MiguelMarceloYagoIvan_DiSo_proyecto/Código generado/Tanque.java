package Estructura;

import java.util.*;

/**
 * Añade al dron ligero el armamento pesado que potencia su ataque y le permite alcanzar objetivos a dos celdas de distancia.
 */
public class Tanque extends Equipador {

    /**
     * Default constructor
     */
    public Tanque() {
    }

    /**
     * 
     */
    public void ataqueDoble() {
        // TODO implement here
    }

}
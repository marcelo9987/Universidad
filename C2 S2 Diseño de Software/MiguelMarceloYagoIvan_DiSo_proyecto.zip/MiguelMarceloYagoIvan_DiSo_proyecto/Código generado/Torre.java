package Estructura;

import java.util.*;

/**
 * Tipo de Estructura.
 */
public class Torre extends Estructura implements IObservador {

    /**
     * Default constructor
     */
    public Torre() {
    }

    /**
     * 
     */
    public void crearUnidad() {
        // TODO implement here
    }

    /**
     * @param unidades
     */
    public void comprobarUnidadEnRango(Unidad unidades) {
        // TODO implement here
    }

    /**
     * 
     */
    public void atacarUnidadesCercanas() {
        // TODO implement here
    }

    /**
     * @param unidadAanhadir
     */
    public void registrarUnidadEnRango(Unidad unidadAanhadir) {
        // TODO implement here
    }

    /**
     * @param unidadFueraDeRango
     */
    public void eliminarUnidadEnRango(Unidad unidadFueraDeRango) {
        // TODO implement here
    }

    /**
     * 
     */
    public void Actualizar() {
        // TODO implement here
    }

}
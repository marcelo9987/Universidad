package Estructura;

import java.util.*;

/**
 * Añade al dron el equipamiento necesario para poder volar, lo que le permite desplazarse dos celdas en un solo movimiento. Además, se puede desplazar en diagonal.
 */
public class UAV extends Equipador {

    /**
     * Default constructor
     */
    public UAV() {
    }

    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

    /**
     * 
     */
    public void mover() {
        // TODO implement here
    }

}
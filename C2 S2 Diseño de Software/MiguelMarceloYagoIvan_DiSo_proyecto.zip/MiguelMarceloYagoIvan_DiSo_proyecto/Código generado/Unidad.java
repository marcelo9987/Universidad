package Estructura;

import java.util.*;

/**
 * Clase abstracta de la que heredan las clases Rover, Dron y Robot, las diferentes unidades que una Potencia puede tener.
 */
public abstract class Unidad {

    /**
     * Default constructor
     */
    public Unidad() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private float salud;

    /**
     * 
     */
    private Integer defensa;

    /**
     * 
     */
    private Integer ataque;

    /**
     * 
     */
    private void celda;

    /**
     * 
     */
    private float recursos;

    /**
     * @param coordX 
     * @param coordY
     */
    public void mover(void coordX, void coordY) {
        // TODO implement here
    }

    /**
     * Operación para notificar a los observadores (torres).
     */
    public void notificarMovimiento() {
        // TODO implement here
    }

    /**
     * 
     */
    public void atacar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void recibirDaño() {
        // TODO implement here
    }

}